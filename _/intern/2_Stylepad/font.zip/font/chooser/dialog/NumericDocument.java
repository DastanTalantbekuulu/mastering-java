package font.chooser.dialog;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class NumericDocument extends PlainDocument {

    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
        if (str == null || offs > 1) {
            return;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return;
            }
        }
        super.insertString(offs, str, a);
    }
}
