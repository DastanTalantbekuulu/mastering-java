package font.chooser.dialog;

import font.chooser.listener.FamilySelectionListener;
import font.chooser.listener.FamilyTextFieldSearchListener;
import font.chooser.listener.FontChooserActionListener;
import font.chooser.listener.SizeSelectionListener;
import font.chooser.listener.SizeTextFieldListener;
import font.chooser.listener.StyleSelectionListener;
import font.chooser.model.FontContainer;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import java.awt.BorderLayout;
import java.awt.Font;

public class FontChooser extends JDialog {
    private FontContainer fontContainer;
    private JComponent component;

    public FontChooser(JFrame frame, JComponent component) {
        super(frame, "Font Chooser");
        this.component= component;
        Position pos = new Position(700, 500);

        JLabel labelFamily = new JLabel("Family");
        labelFamily.setBounds(pos.labelFamily[0],
                pos.labelFamily[1],
                pos.labelFamily[2],
                pos.labelFamily[3]);

        JLabel labelStyle = new JLabel("Style");
        labelStyle.setBounds(pos.labelStyle[0],
                pos.labelStyle[1],
                pos.labelStyle[2],
                pos.labelStyle[3]);

        JLabel labelSize = new JLabel("Size");
        labelSize.setBounds(pos.labelSize[0],
                pos.labelSize[1],
                pos.labelSize[2],
                pos.labelSize[3]);

        LabelListCellRenderer labelListCellRenderer = new LabelListCellRenderer();

        fontContainer = FontContainer.getInstance();
        JLabel labelPreview = fontContainer.getLabelPreview();

        fontContainer.getFamilyList().addListSelectionListener(new FamilySelectionListener());
        fontContainer.getFamilyList().setCellRenderer(labelListCellRenderer);

        fontContainer.getStyleList().addListSelectionListener(new StyleSelectionListener());
        fontContainer.getStyleList().setCellRenderer(labelListCellRenderer);

        fontContainer.getSizeList().addListSelectionListener(new SizeSelectionListener());

        labelPreview.setText("AaBbCcDdEeFfJjKkLlNnOoPpQqSsTtUuVvWwXxYyZz");
        labelPreview.setBorder(new TitledBorder("Preview"));
        labelPreview.setBounds(pos.labelPreview[0],
                pos.labelPreview[1],
                pos.labelPreview[2],
                pos.labelPreview[3]);

        JScrollPane scrollPaneFamily = new JScrollPane(fontContainer.getFamilyList());
        scrollPaneFamily.setBounds(pos.scrollPaneFamily[0],
                pos.scrollPaneFamily[1],
                pos.scrollPaneFamily[2],
                pos.scrollPaneFamily[3]);

        JScrollPane scrollPaneStyle = new JScrollPane(fontContainer.getStyleList());
        scrollPaneStyle.setBounds(pos.scrollPaneStyle[0],
                pos.scrollPaneStyle[1],
                pos.scrollPaneStyle[2],
                pos.scrollPaneStyle[3]);

        JScrollPane scrollPaneSize = new JScrollPane(fontContainer.getSizeList());
        scrollPaneSize.setBounds(pos.scrollPaneSize[0],
                pos.scrollPaneSize[1],
                pos.scrollPaneSize[2],
                pos.scrollPaneSize[3]);

        JTextField textFieldFamily = new JTextField();
        textFieldFamily.getDocument().addDocumentListener(
                new FamilyTextFieldSearchListener());
        textFieldFamily.setBounds(pos.textFieldFamily[0],
                pos.textFieldFamily[1],
                pos.textFieldFamily[2],
                pos.textFieldFamily[3]);

        JTextField textFieldSize = new JTextField();
        textFieldSize.setDocument(new NumericDocument());
        textFieldSize.getDocument().addDocumentListener(
                new SizeTextFieldListener());
        textFieldSize.setBounds(pos.textFieldSize[0],
                pos.textFieldSize[1],
                pos.textFieldSize[2],
                pos.textFieldSize[3]);

        FontChooserActionListener fontChooserActionListener = new FontChooserActionListener(this);
        addWindowListener(fontChooserActionListener);

        JButton buttonOK = new JButton("OK");
        buttonOK.addActionListener(fontChooserActionListener);
        buttonOK.setActionCommand("OK");
        buttonOK.setBounds(pos.buttonOK[0],
                pos.buttonOK[1],
                pos.buttonOK[2],
                pos.buttonOK[3]);

        JButton buttonCancel = new JButton("Cancel");
        buttonCancel.addActionListener(fontChooserActionListener);
        buttonCancel.setActionCommand("Cancel");
        buttonCancel.setBounds(pos.buttonCancel[0],
                pos.buttonCancel[1],
                pos.buttonCancel[2],
                pos.buttonCancel[3]);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.add(labelFamily);
        panel.add(labelStyle);
        panel.add(labelSize);
        panel.add(labelPreview);
        panel.add(textFieldFamily);
        panel.add(textFieldSize);
        panel.add(scrollPaneFamily);
        panel.add(scrollPaneStyle);
        panel.add(scrollPaneSize);
        panel.add(buttonOK);
        panel.add(buttonCancel);

        add(panel, BorderLayout.CENTER);
        setBounds(200, 100, pos.width, pos.height);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    public Font get() {
        return fontContainer.getFont();
    }

    public void set(){
        component.setFont(fontContainer.getFont());
    }
    public void cancel(){
        fontContainer.setFont(component.getFont());
    }

}
