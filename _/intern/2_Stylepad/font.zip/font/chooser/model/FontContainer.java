package font.chooser.model;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.SwingConstants;
import java.awt.Font;

public class FontContainer {

    private static FontContainer INSTANCE;

    private final FontData fontData;
    private JList<JLabel> familyList;
    private JList<JLabel> styleList;
    private JList<Integer> sizeList;
    private float size;
    private JLabel labelPreview;

    private FontContainer() {
        fontData = new FontData();
        labelPreview = new JLabel();
        labelPreview.setHorizontalAlignment(SwingConstants.CENTER);
        labelPreview.setVerticalAlignment(SwingConstants.CENTER);
        familyList = new JList<>(fontData.getFamilyList());
        familyList.setSelectedIndex(0);
        styleList = new JList<>(fontData.getStyleList(fontData.getFamilyList().get(0).getText()));
        styleList.setSelectedIndex(0);
        sizeList = new JList<>(fontData.getSizeList());
        sizeList.setSelectedIndex(4);
        size = FontFamily.DEFAULT_SIZE;
        setStyle();
    }

    public static FontContainer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new FontContainer();
        }
        return INSTANCE;
    }

    public JList<JLabel> getFamilyList() {
        return familyList;
    }

    public JList<JLabel> getStyleList() {
        return styleList;
    }

    public JList<Integer> getSizeList() {
        return sizeList;
    }

    public void setFont(Font font) {
        String style = font.getFamily().equals(font.getName()) ?
                "Default" : font.getName().replace(font.getFamily(), "");
        setFamily(font.getFamily());
        setStyle(style);
        setSize(font.getSize());
    }

    public void setFamily() {
        styleList.setModel(fontData.getStyleList(familyList.getSelectedValue().getText()));
        styleList.setSelectedIndex(0);
        setStyle();
    }

    public void setFamily(String family) {
        for (int i = 0; i < familyList.getModel().getSize(); i++) {
            if (familyList.getModel().getElementAt(i).getText().equals(family)) {
                familyList.setSelectedIndex(i);
                break;
            }
        }
        styleList.setModel(fontData.getStyleList(family));
    }

    public void setStyle() {
        if (!styleList.isSelectionEmpty()) {
            labelPreview.setFont(styleList
                    .getSelectedValue()
                    .getFont()
                    .deriveFont(size));
        }
    }

    public void setStyle(String style) {
        for (int i = 0; i < styleList.getModel().getSize(); i++) {
            if (styleList.getModel().getElementAt(i).getText().equals(style)) {
                styleList.setSelectedIndex(i);
                break;
            }
        }
    }

    public void setSize() {
        this.size = sizeList.getSelectedValue().floatValue();
        updateSize();
    }

    public void setSize(float size) {
        this.size = size;
        updateSize();
    }

    private void updateSize() {
        labelPreview.setFont(labelPreview.getFont().deriveFont(size));
    }

    public JLabel getLabelPreview() {
        return labelPreview;
    }

    public Font getFont() {
        return labelPreview.getFont();
    }

    public void find(String str) {
        JLabel label = fontData.find(
                str.replaceFirst(str.charAt(0) + "", Character.toUpperCase(str.charAt(0)) + ""));
        familyList.setSelectedValue(label, true);
        setFamily();
    }
}
