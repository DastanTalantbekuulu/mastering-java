package font.chooser.model;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.NavigableMap;
import java.util.TreeMap;

class FontFamily {

    public static final float DEFAULT_SIZE = 12.0f;

    private JLabel label;
    private NavigableMap<String, JLabel> fonts;
    private DefaultListModel<JLabel> fontList;

    public FontFamily(JLabel label, Font[] fonts) {
        this.label = label;
        this.fonts = new TreeMap<>();
        fontList = new DefaultListModel<>();
        add(fonts);
    }

    private void add(Font[] fonts) {
        for (Font font : fonts) {
            if (font.getFamily().equals(label.getText())) {
                add(font);
            }
        }
    }

    private void add(Font font) {
        String style = getNameStyle(font);
        JLabel styleLabel = new JLabel(style);
        styleLabel.setFont(font.deriveFont(DEFAULT_SIZE));
        fonts.put(style, styleLabel);
        fontList.addElement(styleLabel);
    }
    public String getNameStyle(Font font){
        return font.getFamily().equals(font.getName()) ? "Default" : font.getName().replace(label.getText(), "");
    }

    public Font get(String name) {
        return fonts.get(name).getFont();
    }

    public Font getDefaultStyle() {
        return fonts.firstEntry().getValue().getFont();
    }

    public DefaultListModel<JLabel> getList() {
        return fontList;
    }

    public JLabel getStyle(String style) {
        return fonts.get(style);
    }
}
