package font.chooser.model;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.NavigableMap;
import java.util.TreeMap;

class FontData {

    private NavigableMap<String, FontFamily> fontTable;
    private DefaultListModel<JLabel> families;
    private DefaultListModel<Integer> sizes;

    public FontData() {
        families = new DefaultListModel<>();
        fontTable = new TreeMap<>();
        sizes = new DefaultListModel<>();

        String[] listFamily = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        Font[] allFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        int[] sizes = new int[]{8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72};

        add(listFamily, allFonts);
        addSizes(sizes);
    }

    private void add(String[] family, Font[] fonts) {
        for (String string : family) {
            add(string, fonts);
        }
    }

    private void add(String family, Font[] fonts) {
        JLabel label = new JLabel(family);
        families.addElement(label);
        FontFamily fontFamily = new FontFamily(label, fonts);
        fontTable.put(family, fontFamily);
        label.setFont(fontFamily.getDefaultStyle());
    }

    private void addSizes(int[] sizes) {
        for (int size : sizes) {
            this.sizes.addElement(size);
        }
    }

    public DefaultListModel<JLabel> getFamilyList() {
        return families;
    }

    public DefaultListModel<JLabel> getStyleList(String style) {
        return fontTable.get(style).getList();
    }

    public DefaultListModel<Integer> getSizeList() {
        return sizes;
    }

    public JLabel find(String str) {
        String key = fontTable.ceilingKey(str);
        for (int i = 0; i < families.size(); i++) {
            if (families.get(i).getText().equals(key)) {
                return families.get(i);
            }
        }
        return null;
    }

    public JLabel get(String family, String style) {
        return fontTable.get(family).getStyle(style);
    }
}