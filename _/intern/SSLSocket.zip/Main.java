import java.io.File;

public class Main {
    public static void main(String[] args) {
        File theDir = new File("./result");
        if (!theDir.exists()){
            theDir.mkdir();
        }
        Registration.run();
        Authorization.run();
    }
}
